//
//  SecondViewController.h
//  TestFraemwork
//
//  Created by Ivan Androsenko on 01.07.16.
//  Copyright © 2016 Ivan Androsenko. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController
- (IBAction)aaaa:(id)sender;

@end
