//
//  ShareViewController.h
//  TestFraemwork
//
//  Created by Ivan Androsenko on 01.07.16.
//  Copyright © 2016 Ivan Androsenko. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShareViewController : UIViewController
- (IBAction)pressedButton:(id)sender;

@end
