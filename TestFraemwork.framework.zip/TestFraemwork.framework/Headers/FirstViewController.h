//
//  FirstViewController.h
//  TestFraemwork
//
//  Created by Ivan Androsenko on 01.07.16.
//  Copyright © 2016 Ivan Androsenko. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *buttonQuestion;
- (IBAction)pressedQuestion:(id)sender;

@end
