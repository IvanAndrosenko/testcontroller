//
//  TestFraemwork.h
//  TestFraemwork
//
//  Created by Ivan Androsenko on 01.07.16.
//  Copyright © 2016 Ivan Androsenko. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TestFraemwork.
FOUNDATION_EXPORT double TestFraemworkVersionNumber;

//! Project version string for TestFraemwork.
FOUNDATION_EXPORT const unsigned char TestFraemworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestFraemwork/PublicHeader.h>


